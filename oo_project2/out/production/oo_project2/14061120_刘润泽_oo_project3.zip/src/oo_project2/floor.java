package oo_project2;

/**
 * 电梯在哪一层
 * Created by DESTRooooYER on 2016/3/8.
 */
public class floor
{
	private int n;

	public int getN()
	{
		return this.n;
	}

	public void setN(int x)
	{
		this.n = x;
	}
}
